# 03 · 为什么两个独立 verifier 测试在构造环境时失败？

**当前判断**　已定位为测试夹具的入参差异。

## 问题在哪里

Harbor 创建独立 verifier 时把日志目录放进 `auto_mounts`。Dressage 测试助手 `_environment` 把同一项放进 `mounts`。Harbor 随后补上默认自动挂载，Dressage 的 `_is_separate_verifier_session` 看到的目标集合发生变化，报 `separate verifier does not have Harbor's verifier mount shape`。 [Harbor 创建独立 verifier · trial.py 第 1115 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L1115-L1127) · [夹具传入 mounts · test_environment.py 第 60 行](../../../../tests/integrations/harbor/test_environment.py#L60) · [Dressage 对 verifier 挂载的识别 · environment.py 第 238 行](../../../../dressage/integrations/harbor/environment.py#L238-L257)

## 打算怎么接入

让用于 0.26 的夹具传入与真实 Trial 一致的 `auto_mounts`，保留独立 verifier 的目录和权限约束。0.18 的对照仍按旧版真实调用构造。

## 怎么验收

复跑两个曾失败的环境用例，断言独立 verifier 只取得它自己的自动日志挂载，然后运行完整 `test_environment.py`。非空日志的回收有单独的验收用例。 [Agent 与 verifier 隔离测试 · test_environment.py 第 77 行](../../../../tests/integrations/harbor/test_environment.py#L77) · [真实 bwrap 用例 · test_environment.py 第 193 行](../../../../tests/integrations/harbor/test_environment.py#L193) · [非空日志回收](../02-output-mounts/README.md)

**一行差异的对照**　基线失败位置和应用补丁后的四项通过均已留存。该实验只改临时导出的测试输入，因此可以据此对齐夹具。非空日志仍需用问题 02 的文件探测独立验收。[三版基线失败项](../00-version-target/pytest-replay.txt) · [一行补丁](auto-mounts.patch) · [四项环境测试输出](fixture-pytest.txt) · [复现命令](../../reproduce.md#suite)

## 判断记录

- 2026-11-18　原始 0.26 默认套件共三项失败，其中两项共用该夹具。仅在临时副本对齐参数，整个环境文件四项通过。随后独立发现非空日志回收失败，两项修复各自验收。

[返回问题索引](../../README.md#issues)
