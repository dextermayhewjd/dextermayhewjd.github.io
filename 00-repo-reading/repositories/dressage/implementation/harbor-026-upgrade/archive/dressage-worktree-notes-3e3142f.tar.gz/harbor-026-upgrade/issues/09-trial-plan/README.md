# 09 · JobPlan 生成的 Trial 还能正确对应 Dressage 的题目和尝试吗？

**当前判断**　已有真实 Job 探测，保留分组逻辑并补回归。

## 问题在哪里

Harbor `JobPlan.build_trial_configs` 生成待运行 Trial。Dressage 的 `compat.build_trial_plan` 读取 Job 的 `_task_configs`、`_remaining_trial_configs`，依赖排列顺序并检查 task、agent 对象身份。任务解析也经 `compat` 接触 Harbor 的 `_resolve_task_configs`。 [Harbor 的 Trial 计划 · job_plan.py 第 143 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/job_plan.py#L143) · [Dressage 的身份和顺序校验 · compat.py 第 121 行](../../../../dressage/integrations/harbor/compat.py#L121-L165)

## 打算怎么接入

保持当前按 attempt → task → agent 的配对方式，把真实 Job 加进合同测试。测试须从真实配置和任务解析进入，能及早发现上游是否复制了 task 或 agent 对象。

## 怎么验收

用单题及 `2 个 attempt × 2 道题 × 2 个 Agent` 两种输入。校验八个位置分别交给哪个题目和 Agent、分配的 Trial 名是否唯一，再把每个位置对应回原始模板。 [现有手工 Job 的计划测试 · test_contracts.py 第 108 行](../../../../tests/integrations/harbor/test_contracts.py#L108)

**本地复查**　运行本目录的 `python probe.py`，可看到 1 个和 8 个 Trial 的完整位置三元组。Probe 复用本仓库的 `RecordingRuntime`，在候选版本上仅为这个进程临时调整期望版本。此结果支持保留 `build_trial_plan` 的配对与身份检查。[探测脚本](probe.py) · [三版实测输出](trial-plan-output.txt) · [两道本地题](tasks)

## 判断记录

- 2026-11-11　看到 Harbor 引入 JobPlan，先把对象身份与排列列为待验证。
- 2026-11-18　此前的真实 Job 探测临时放行版本检查，0.25 和 0.26 的顺序、对象身份和 Trial 数量均符合预期。可在独立 Dressage 分支固化该用例。Job 的私有成员集中在 `compat.py`，另一个已知的私有依赖 `_mounts` 属于环境后端。

[返回问题索引](../../README.md#issues)
