Identify the word "second".
