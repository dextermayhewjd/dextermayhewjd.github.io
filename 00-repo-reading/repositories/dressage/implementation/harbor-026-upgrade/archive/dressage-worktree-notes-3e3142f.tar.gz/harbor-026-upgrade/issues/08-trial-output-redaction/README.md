# 08 · Trial 目录脱敏时，Dressage 的 bundle 应该放在哪里？

**当前判断**　路径约束已定位，文件级验收待补。

## 问题在哪里

Harbor 在 `Trial.run` 的收尾阶段扫描 Trial 目录。Dressage 在提交 bundle 时另行检查输出路径位于该 Trial 目录之外。路由模板由插件写入 Agent 配置，实际凭证在运行时解析。 [Harbor 脱敏扫描的范围 · trial.py 第 1247 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L1247-L1332) · [提交前检查输出路径 · artifacts.py 第 482 行](../../../../dressage/integrations/harbor/artifacts.py#L482) · [禁止 bundle 落在 Trial 目录内 · artifacts.py 第 1133 行](../../../../dressage/integrations/harbor/artifacts.py#L1133)

## 打算怎么接入

保持两个目录的职责。给 Trial 目录和 bundle 目录分别配置临时路径，在本次升级验证 Harbor 清理 Trial 输出后 Dressage 还能读取提交的 bundle。

## 怎么验收

只使用合成凭证。检查 Harbor 声明处理的输出文件完成脱敏，外部 bundle 仍可读取，其应公开的配置字段符合 Dressage 的脱敏约定。另用位于 Trial 内部的输出路径验证 Dressage 的拒绝分支。 [bundle 原子提交与 schema 测试 · test_data_path.py 第 65 行](../../../../tests/integrations/harbor/test_data_path.py#L65)

**PR 判断依据**　当前可回查的是 Trial 内外目录的静态约束和已有提交测试。原临时材料没有留下“脱敏前 → 收尾后”的文件样例。保持现有路径检查，获得合成凭证的文件级对照后再判断是否需要修复。[路径检查](../../../../dressage/integrations/harbor/artifacts.py#L1133) · [已有提交测试](../../../../tests/integrations/harbor/test_data_path.py#L65)

## 判断记录

- 2026-11-18　源码核对确认两端各自的路径检查。全目录、任意第三方日志的脱敏效果尚无实测证据。

[返回问题索引](../../README.md#issues)
