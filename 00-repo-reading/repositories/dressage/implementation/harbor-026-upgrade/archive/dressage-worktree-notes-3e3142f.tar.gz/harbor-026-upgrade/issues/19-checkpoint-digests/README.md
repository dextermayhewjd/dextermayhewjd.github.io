# 19 · 升级后，旧数据源 checkpoint 还能被正确识别吗？

**当前判断**　已观测到 source 摘要不同，完整恢复待验证。

## 问题在哪里

`HarborDataSource.save/load` 保存并核对数据源标识。`_source_digest` 包含脱敏后的整个 Job 配置，`_registry_digest` 从 spec 的身份、指纹和顺序等字段计算。新版配置模型的 dump 可能改变前者。 [保存与恢复时核对身份 · data_source.py 第 357 行](../../../../dressage/integrations/harbor/data_source.py#L357-L416) · [两个摘要各自的输入 · data_source.py 第 829 行](../../../../dressage/integrations/harbor/data_source.py#L829-L854)

## 打算怎么接入

保留现有漂移检查。先验收同版保存和恢复，再验证旧版 checkpoint 在新版上的实际处理。根据维护者承诺，明确记录跨版拒绝或设计可验证的迁移。

## 怎么验收

用同一 Job、`n_samples=2`、`seed=7`、`shuffle=False` 保存并恢复，对照 cursor、任务身份和错误原因。分别测量 source 与 registry 摘要，当前数据只证明 source 摘要变化。 [数据源漂移测试 · test_data_path.py 第 400 行](../../../../tests/integrations/harbor/test_data_path.py#L400) · [端到端 checkpoint 测试 · test_gated_e2e.py 第 142 行](../../../../tests/integrations/harbor/test_gated_e2e.py#L142)

**本地复查**　问题 18 的同一行输出给出 `_source_digest` 前缀，输入参数固定。摘要在三个版本间变化，支持保留漂移检查并补跨版恢复验收。此观测没有执行 `load`，也没有测量 `_registry_digest`。[计算脚本](../18-example-configs/probe.py) · [实际摘要](../18-example-configs/job-config-output.txt)

## 判断记录

- 2026-11-18　同一输入的 `_source_digest` 前缀如下。0.26 的新增默认字段是一个已知输入差异，摘要变化的全部原因尚未逐字段归因。完整跨版 `load` 尚未执行。

| 随仓 Job | Harbor 0.18.0 | Harbor 0.25.0 | Harbor 0.26.0 |
| --- | --- | --- | --- |
| terminal-bench-2-e2b | `10dc1bcdefa215` | `5ad32833f41bae` | `eaa28aafd82982` |
| tau3-bench-e2b | `fcfdd07989fbb9` | `0ccb8257941113` | `9780cd6492be13` |

[返回问题索引](../../README.md#issues)
