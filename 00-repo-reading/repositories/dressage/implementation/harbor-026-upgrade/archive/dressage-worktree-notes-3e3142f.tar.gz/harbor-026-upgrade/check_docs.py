"""Check the local upgrade notes and optionally their tagged Harbor source locations."""

import argparse
import re
import subprocess
from functools import lru_cache
from pathlib import Path
from urllib.parse import unquote, urlsplit


@lru_cache(maxsize=None)
def tagged_source(checkout: Path, tag: str, path: str) -> str:
    return subprocess.check_output(["git", "-C", str(checkout), "show", f"{tag}:{path}"], text=True)


def check_fragment(content: str, fragment: str) -> None:
    lines = re.fullmatch(r"L(\d+)(?:-L(\d+))?", fragment)
    if lines:
        first = int(lines[1])
        last = int(lines[2] or first)
        if not 1 <= first <= last <= len(content.splitlines()):
            raise ValueError(f"source line out of range: {fragment}")
    elif fragment and f'id="{fragment}"' not in content:
        raise ValueError(f"missing anchor: {fragment}")


def check(root: Path, harbor_repo: Path | None) -> None:
    index = (root / "README.md").read_text()
    issues = sorted((root / "issues").glob("*/README.md"))
    if not issues:
        raise ValueError("the index has no issue directories")
    for issue in issues:
        if f"({issue.relative_to(root).as_posix()})" not in index:
            raise ValueError(f"issue not linked from index: {issue.parent.name}")
    checked = 0
    sources = 0
    for page in sorted(root.rglob("*.md")):
        for link in re.findall(r"\[[^\]\n]*\]\(([^)\n]+)\)", page.read_text()):
            url = urlsplit(link)
            try:
                if not url.scheme:
                    target = (page.parent / unquote(url.path)).resolve() if url.path else page
                    if not target.exists():
                        raise ValueError("missing local target")
                    if url.fragment:
                        check_fragment(target.read_text(), url.fragment)
                    checked += 1
                elif harbor_repo and url.netloc == "github.com":
                    source = re.fullmatch(r"/harbor-framework/harbor/blob/(v[\d.]+)/(.+)", url.path)
                    if source:
                        check_fragment(tagged_source(harbor_repo, *source.groups()), url.fragment)
                        sources += 1
            except (OSError, ValueError, subprocess.CalledProcessError) as exc:
                raise SystemExit(f"{page.relative_to(root)}: {link}: {exc}") from exc
    print(f"{len(issues)} issue folders indexed; {checked} local links checked")
    if harbor_repo:
        print(f"{sources} tagged Harbor source links checked")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harbor-repo", type=Path, help="Harbor checkout containing the release tags")
    check(Path(__file__).resolve().parent, parser.parse_args().harbor_repo)
