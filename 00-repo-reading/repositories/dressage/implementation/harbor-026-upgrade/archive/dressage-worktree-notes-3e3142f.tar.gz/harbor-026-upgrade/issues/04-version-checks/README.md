# 04 · 哪些地方仍要求安装和运行 Harbor 0.18.0？

**当前判断**　已确认版本限制，随本次适配更新。

## 问题在哪里

Dressage 的 Harbor extra 固定 `harbor==0.18.0`，`compat.require_harbor_runtime` 在运行时也比较精确版本。DAPO 数据准备脚本还有独立检查，集成说明和一项合同测试也写死了旧版本。 [安装依赖与插件注册 · pyproject.toml 第 21 行](../../../../pyproject.toml#L21-L27) · [运行时检查 · compat.py 第 37 行](../../../../dressage/integrations/harbor/compat.py#L37-L60) · [DAPO 版本检查 · prepare_dataset.py 第 556 行](../../../../examples/harbor/dataset_tools/dapo/prepare_dataset.py#L556) · [随仓安装说明 · harbor.md 第 51 行](../../../../docs/harbor.md#L51)

## 打算怎么接入

根据已验收的版本同步 extra、两处运行检查、测试和安装示例。保持 Harbor 是可选依赖，普通导入 Dressage 仍适用于其 Python 3.10 基线。Harbor 集成沿用 Python 3.12 或以上的要求。

## 怎么验收

在干净的 Python 3.12 环境安装 Dressage 的 Harbor extra，验证实际安装版本、`require_harbor_runtime()` 和 DAPO 入口行为一致。对明确不支持的版本保留拒绝行为。Job YAML 的字段验证有独立用例。 [运行时合同测试 · test_contracts.py 第 108 行](../../../../tests/integrations/harbor/test_contracts.py#L108) · [固定安装版本的断言 · test_contracts.py 第 165 行](../../../../tests/integrations/harbor/test_contracts.py#L165) · [可选依赖的导入边界 · __init__.py 第 1 行](../../../../dressage/integrations/harbor/__init__.py#L1)

**要改的依据**　基线的安装版本断言在两个候选版本都失败。独立进程调用 `require_harbor_runtime()` 也都返回版本错误。问题 09 在记录拒绝之后才临时放行，用于观察后续计划逻辑。发布时仍需以真实安装和原版本检查为验收入口。[测试失败项](../00-version-target/pytest-replay.txt) · [原版本检查输出](../09-trial-plan/trial-plan-output.txt)

## 判断记录

- 2026-11-18　0.26 默认套件的第三项失败来自 `test_official_jobs_validate_with_harbor_018` 的旧版本断言，发生在 YAML 校验之前。该结果能定位版本限制，YAML 兼容性另有直接验证。

[返回问题索引](../../README.md#issues)
