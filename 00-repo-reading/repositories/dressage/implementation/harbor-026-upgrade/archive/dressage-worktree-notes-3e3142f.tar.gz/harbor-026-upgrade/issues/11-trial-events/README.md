# 11 · 真实 Trial 正常结束或被取消时，插件何时提交并关闭路由？

**当前判断**　六个回调可注册，真实事件时序待验收。

## 问题在哪里

`DressageHarborPlugin.on_job_start` 向 Job 注册 START、AGENT_START、AGENT_END、VERIFICATION_START、CANCEL、END。新版 Harbor 在取消后先发 CANCEL，再关 bridge、回收输出，并在 `_finalize` 发 END。Dressage 在 `_on_cancel` 标记状态，`_on_end` 委派 `_finalize_attempt` 提交结果并尝试关闭路由。 [六个事件注册入口 · plugin.py 第 407 行](../../../../dressage/integrations/harbor/plugin.py#L407-L414) · [Trial 的取消与 finally · trial.py 第 608 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L608-L634) · [Trial 发出 END · trial.py 第 667 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L667) · [Dressage 收到 CANCEL 和 END · plugin.py 第 731 行](../../../../dressage/integrations/harbor/plugin.py#L731-L807)

## 打算怎么接入

保留插件的事件分工。用 Harbor 自己发出事件，检查回收输出、提交 bundle、关闭路由的先后关系。发现时序差异时在对应钩子修复。

## 怎么验收

分别运行一次正常 Trial 和一次运行中取消的 Trial。记录真实事件顺序，检查同一尝试只提交一次、取消状态能查到、路由释放。当前插件测试手动触发钩子，可继续用于单元回归。 [插件到 Sample 的现有用例 · test_execution.py 第 64 行](../../../../tests/integrations/harbor/test_execution.py#L64) · [端到端失败场景 · test_gated_e2e.py 第 168 行](../../../../tests/integrations/harbor/test_gated_e2e.py#L168)

**当前证据能走到哪里**　单题和八 Trial 两种输入都登记了六个钩子。输出中的 `registered` 是注册结果。真实 Trial 发出 CANCEL 和 END、关闭路由的先后顺序仍需由正常和取消流程观测。[注册探测](../09-trial-plan/probe.py) · [逐版注册结果](../09-trial-plan/trial-plan-output.txt)

## 判断记录

- 2026-11-18　单题和八 Trial 的真实 Job 均能登记六个回调，探测停在注册阶段。0.18 与新版在取消和输出回收的先后关系上有差异，因此实际退出顺序单列验收。

[返回问题索引](../../README.md#issues)
