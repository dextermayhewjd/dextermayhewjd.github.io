# 14 · Harbor 合并各阶段网络策略后，bwrap 还能使用预期的 Gateway 吗？

**当前判断**　保留受限网络约束，单步和多步场景待验证。

## 问题在哪里

`_task_network_class` 按任务和各 step 的 Agent 配置判定是否允许 `enforced` 路由。插件把 Gateway 主机加入 Agent 配置，Harbor 对静态环境合并阶段策略。bwrap 收到 allowlist 后要求其内容只有 `127.0.0.1`。 [任务网络分类与检查 · plugin.py 第 1099 行](../../../../dressage/integrations/harbor/plugin.py#L1099-L1150) · [Agent 的额外允许主机 · plugin.py 第 1066 行](../../../../dressage/integrations/harbor/plugin.py#L1066-L1074) · [静态环境的阶段策略 · base.py 第 341 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/base.py#L341-L364) · [bwrap allowlist · environment.py 第 373 行](../../../../dressage/integrations/harbor/environment.py#L373-L382)

## 打算怎么接入

维持本地 bwrap 经回环 Gateway 的配置。在真实的单步和多步 Task 上核对最终策略与本地 Gateway 地址，如果某一步产生不同 allowlist，在该阶段生成配置的位置适配。

## 怎么验收

用受限任务核对最后的 allowlist 和一次本地 Gateway 请求。另用声明 public 的测试任务，断言 `enforced` 模式拒绝它。远端 native 配置按其自身承诺验收。 [Agent 与 verifier 的隔离用例 · test_environment.py 第 77 行](../../../../tests/integrations/harbor/test_environment.py#L77) · [插件的配置拒绝测试 · test_execution.py 第 128 行](../../../../tests/integrations/harbor/test_execution.py#L128)

**PR 判断依据**　问题 03 的单一夹具修正后，环境测试包含 Agent/verifier 隔离用例。它尚未覆盖真实多步任务的阶段策略合并。下一份证据应记录各阶段产生的 allowlist，再决定是否调整插件配置。[夹具对照结果](../03-verifier-fixture/fixture-pytest.txt) · [隔离测试入口](../../../../tests/integrations/harbor/test_environment.py#L77)

## 判断记录

- 2026-11-18　0.18 已经存在阶段网络配置。0.26 源码仍能定位合并和校验入口。真实多步任务的最终策略尚待实测。

[返回问题索引](../../README.md#issues)
