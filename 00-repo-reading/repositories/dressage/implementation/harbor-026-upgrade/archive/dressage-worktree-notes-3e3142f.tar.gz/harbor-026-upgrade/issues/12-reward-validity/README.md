# 12 · Harbor 认为分数有效时，Dressage 是否应采纳这个训练样本？

**当前判断**　保留 Dressage 的采纳规则，补行为对照。

## 问题在哪里

Harbor 的 `TrialResult.reward_valid` 判断一份评测分数能否计入统计。Dressage 的 `_extract_rewards` 取指定分数，`_harbor_result_failures` 独立检查 Trial 和 step 异常。一次有分数的非零 Agent 退出可能被 Harbor 视为有效，Dressage 仍可将它标为不可训练。 [0.25 的有效性判断 · result.py 第 104 行](https://github.com/harbor-framework/harbor/blob/v0.25.0/src/harbor/models/trial/result.py#L104-L130) · [0.26 的异常枚举和分数判断 · result.py 第 127 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/models/trial/result.py#L127-L149) · [错误与重试策略 · error_policy.py 第 95 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/models/trial/error_policy.py#L95-L125) · [Dressage 提取分数与异常 · artifacts.py 第 1056 行](../../../../dressage/integrations/harbor/artifacts.py#L1056-L1104)

## 打算怎么接入

保持现有训练语义。以真实 Harbor 结果模型输入 artifact store，分别断言 Harbor 的分数有效性和 Dressage 的 `trainable`。若团队希望放宽训练采纳条件，单独评审这个行为变更。

## 怎么验收

覆盖正常有分数、带异常仍有分数、缺少指定分数三种输入。核对 reward 数值、异常信息、`REWARD_MISSING` 和是否允许进入训练。默认重试排除项另由 Harbor 策略生成。 [缺少目标 reward 的判断 · artifacts.py 第 864 行](../../../../dressage/integrations/harbor/artifacts.py#L864) · [已有失败结果矩阵 · test_data_path.py 第 124 行](../../../../tests/integrations/harbor/test_data_path.py#L124)

**PR 判断依据**　现有失败矩阵覆盖 Dressage 输入的异常和缺分处理。原临时探测没有对同一真实 TrialResult 同时记录 `reward_valid` 和 `trainable`。当前保留训练采纳规则，由上面的三种输入决定是否确有适配缺口。[失败矩阵](../../../../tests/integrations/harbor/test_data_path.py#L124) · [分数与异常的消费位置](../../../../dressage/integrations/harbor/artifacts.py#L1056)

## 判断记录

- 2026-11-18　0.25 已有 ErrorPolicy 与 `reward_valid`。0.26 提供 `recorded_exceptions()` 和策略覆盖，并把有效性判断用于 Job 统计。升级没有确立放宽训练样本选择的需求。

[返回问题索引](../../README.md#issues)
