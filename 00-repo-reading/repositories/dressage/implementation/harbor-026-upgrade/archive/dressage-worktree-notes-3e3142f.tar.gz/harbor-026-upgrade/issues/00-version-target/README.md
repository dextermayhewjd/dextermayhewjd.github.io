# 00 · 这次向 Dressage 上游提交哪个 Harbor 版本？

**当前判断**　建议目标为 0.26.0，正式支持范围待维护者确认。

## 问题在哪里

Dressage 发布基线 `3e3142f` 的 Harbor 可选依赖固定为 `0.18.0`。这次可选的两个发布标签是 `v0.25.0`（`fdba28fc`）和 `v0.26.0`（`3cb62739`）。 [Dressage Harbor extra · pyproject.toml 第 22 行](../../../../pyproject.toml#L22) · [0.25.0 发布页](https://github.com/harbor-framework/harbor/releases/tag/v0.25.0) · [0.26.0 发布页](https://github.com/harbor-framework/harbor/releases/tag/v0.26.0)

## 打算怎么接入

建议在 `compat/harbor-0.26` 直接适配精确版本 `0.26.0`。两个候选版本都要处理 bwrap 日志挂载。0.26 还要接受环境工厂传来的 `kwargs`。先发布一次 0.25 适配，之后仍得修改这个入口。保留 `0.18.0` 作为升级前的行为基线，`0.25.0` 用来定位差异。 若下游部署明确锁在 0.25.0，再将 0.25.0 列为单独的交付目标。

## 怎么验收

以同一 Dressage 提交、同一用例比较原版与候选版。若维护者要求发布双版本支持，再把被承诺的版本加入安装和 CI 验收。当前默认测试的旧基线为 0.18.0 通过 66 项，0.26.0 通过 63 项、失败 3 项，两边各排除 8 项 `harbor_e2e`。 [工厂调用对照](../01-environment-preflight/README.md) · [同一份日志的双版本探测](../02-output-mounts/README.md) · [默认测试选择规则 · pyproject.toml 第 43 行](../../../../pyproject.toml#L43)

**版本对照的原件**　原先的 0.18 与 0.26 日志及本次三版复跑都已归档。0.25 与 0.26 的默认套件失败在相同三项。区分两个候选版本还要看工厂预检的真实调用。[0.18 原始日志](pytest-0.18.0.txt) · [0.26 原始日志](pytest-0.26.0.txt) · [三版复跑](pytest-replay.txt) · [工厂对照](../01-environment-preflight/preflight-output.txt)

## 判断记录

- 2026-11-11　先由 0.18 与 0.25 的源码差异定位接口，再用真实调用决定改动范围。 [两个发布标签的源码对比](https://github.com/harbor-framework/harbor/compare/v0.18.0...v0.25.0)
- 2026-11-18　从独立 Dressage 仓库的 `3e3142f` 建立工作树 `Dressage-harbor-0.26`，分支为 `compat/harbor-0.26`。此前个人集成使用的 `3820149e` 属于另一条提交历史。
- 2026-11-18　本次对两个发布版本使用同一份独立 Dressage 代码做了工厂和文件回收探测，据此建议以 0.26.0 为本次 PR 的目标。完整 Trial 与训练接入的验收仍待实施。

[返回问题索引](../../README.md#issues)
