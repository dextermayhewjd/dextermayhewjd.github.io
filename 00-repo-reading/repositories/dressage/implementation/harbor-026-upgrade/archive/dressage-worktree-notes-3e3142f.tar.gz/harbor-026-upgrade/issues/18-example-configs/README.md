# 18 · 随仓两份 Job YAML 还能得到相同的任务、Agent 和环境配置吗？

**当前判断**　三个版本已通过模型解析。

## 问题在哪里

`examples/harbor/harbor_job_configs/` 有 Terminal-Bench 2 和 τ³-bench 的 E2B Job。Dressage 将它们交给 Harbor 的 `JobConfig.model_validate`。旧合同测试先断言 Harbor 等于 0.18.0，再检查字段。 [Terminal-Bench 2 Job · terminal-bench-2-e2b.yaml](../../../../examples/harbor/harbor_job_configs/terminal-bench-2-e2b.yaml) · [τ³-bench Job · tau3-bench-e2b.yaml](../../../../examples/harbor/harbor_job_configs/tau3-bench-e2b.yaml) · [两份 Job 的字段断言 · test_contracts.py 第 165 行](../../../../tests/integrations/harbor/test_contracts.py#L165) · [新增的 schema_version · config.py 第 404 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/models/job/config.py#L404)

## 打算怎么接入

保留已通过解析的示例内容。把安装版本的断言与配置字段的断言独立编写，使测试失败时能判断是装错版本，还是 Job 的含义改变。

## 怎么验收

在目标版解析两份 YAML，逐项断言 dataset 名、Agent 模型名及 E2B 环境类型。真实数据集下载和沙箱运行另行验收。 [安装版本的检查](../04-version-checks/README.md) · [实际启动 E2B](../16-e2b-template/README.md)

**本地复查**　运行本目录的 `python probe.py`。两份 YAML 在三个版本中都解析出预期的 dataset、Agent 模型名和 E2B 环境。两份原配置可以继续使用，该结果与问题 04 的版本断言独立。[探测脚本](probe.py) · [字段与摘要的实测输出](job-config-output.txt)

## 判断记录

- 2026-11-18　0.18.0、0.25.0、0.26.0 对两份随仓 YAML 都通过 `JobConfig.model_validate`。0.26 为 JobConfig、TrialConfig、JobResult、TrialResult 增加默认 `schema_version`。解析成功后仍需考虑 checkpoint 摘要。

[返回问题索引](../../README.md#issues)
