# 07 · Harbor 解析 Agent 配置后，请求还会到达本次 Trial 的 Gateway 吗？

**当前判断**　0.25 已查最终配置，0.26 的实际请求待验证。

## 问题在哪里

`_inject_agent_routing` 为 Agent 写入 Gateway 地址和路由凭证模板。Harbor 随后解析 Agent 的连接配置。Claude Code 可能清空未采用的另一个认证变量。Gateway 用最终请求头选择本次 Trial 的路由，再把请求送到 Dressage Proxy。 [写入路由配置 · plugin.py 第 1031 行](../../../../dressage/integrations/harbor/plugin.py#L1031-L1075) · [Claude Code 解析连接 · claude_code.py 第 169 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/agents/installed/claude_code.py#L169) · [Gateway 读取凭证 · gateway.py 第 1107 行](../../../../dressage/integrations/harbor/gateway.py#L1107-L1126)

## 打算怎么接入

继续按协议注入 Gateway 地址和本次 Trial 的凭证。先从真实 Agent 构造入口读取最终地址和有效凭证，再用本地 Gateway 接收一次无付费的测试请求。若某类 Agent 丢失路由，只修改该协议的注入或连接参数。

## 怎么验收

对承诺支持的协议，用假凭证断言最终地址、路由身份和清理行为。Gateway 接受一个有效凭证，多个非空凭证必须一致。保留已有的替代认证变量检查，并记录哪些 Agent 需要显式覆盖协议。 [Gateway 路由合同 · test_execution.py 第 552 行](../../../../tests/integrations/harbor/test_execution.py#L552) · [替代认证配置检查 · plugin.py 第 1196 行](../../../../dressage/integrations/harbor/plugin.py#L1196)

**当前证据能走到哪里**　问题 09 证实 `on_job_start` 后待运行配置带有 Gateway 地址。0.25 的连接解析另有此前的观察。要决定是否修改注入逻辑，仍需观察目标版 harness 的最终请求是否到达该 Trial 的 Gateway。[配置注入后的实测输出](../09-trial-plan/trial-plan-output.txt) · [已有 Gateway 请求头合同](../../../../tests/integrations/harbor/test_execution.py#L552)

## 判断记录

- 2026-11-18　之前在 0.25 的 Claude Code 配置探测中使用测试模型名与假凭证，解析后 Gateway 地址与 `ANTHROPIC_API_KEY` 仍在，`ANTHROPIC_AUTH_TOKEN` 被清空。此探测没有运行 CLI 的真实请求。

[返回问题索引](../../README.md#issues)
