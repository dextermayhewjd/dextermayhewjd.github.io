# 13 · 同一 Trial 重试后，最终是哪份 bundle 进入训练？

**当前判断**　保留最终选择规则，真实结果到 Sample 的闭环待验收。

## 问题在哪里

`HarborArtifactStore.commit_attempt` 保存每次尝试的 bundle。训练路径在 `_bundle_samples` 将最终结果转换为 Sample，`_run_partition` 校验组内轨迹数量和权重版本，再把成功组的 `final_keys` 交给 `write_job_manifest`。落盘成功与最终采纳发生在两个位置。 [保存单次尝试 · artifacts.py 第 256 行](../../../../dressage/integrations/harbor/artifacts.py#L256) · [将 bundle 转成 Sample · rollout.py 第 624 行](../../../../dressage/integrations/harbor/rollout.py#L624-L675) · [组校验后提交最终选择 · rollout.py 第 840 行](../../../../dressage/integrations/harbor/rollout.py#L840-L875) · [写入最终 manifest · artifacts.py 第 537 行](../../../../dressage/integrations/harbor/artifacts.py#L537)

## 打算怎么接入

沿用 JobResult 的最终 Trial 身份以及 Dressage 的整组校验。CLI rollout 的 Job 结束钩子与训练分区写 manifest 的时机各自保留。只有真实 Harbor 返回的身份或结果形状改变时，才在这个交接点适配。

## 怎么验收

用首次尝试失败、重试成功的同一题，检查两份尝试可追踪，返回的 Sample 和最终 manifest 都指向选中的尝试。再验证组校验失败时没有该组的最终 key。分别检查 `superseded` 与 `trainable`。 [插件的 Job 结束入口 · plugin.py 第 420 行](../../../../dressage/integrations/harbor/plugin.py#L420-L437) · [manifest 最终选择与撤销 · test_data_path.py 第 201 行](../../../../tests/integrations/harbor/test_data_path.py#L201) · [插件重试用例 · test_execution.py 第 215 行](../../../../tests/integrations/harbor/test_execution.py#L215)

**PR 判断依据**　可复用现有重试和 manifest 用例核对最终 key。实际从目标版 Harbor 重试到最终 Sample 的输出尚未归档，保留当前选择规则并把真实交接列为 PR 验收。[重试用例](../../../../tests/integrations/harbor/test_execution.py#L215) · [manifest 用例](../../../../tests/integrations/harbor/test_data_path.py#L201)

## 判断记录

- 2026-11-18　源码复核确认取消影响样本可训练性，`superseded` 由最终选择决定。现有用例覆盖合成结果，目标版真实 Trial 到训练 Sample 的交接仍需验收。

[返回问题索引](../../README.md#issues)
