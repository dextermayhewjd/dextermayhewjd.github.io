# 02 · 为什么 Harbor 回收日志时会把目录复制回它自己？

**当前判断**　已在 0.25.0 与 0.26.0 复现，确定修复。

## 问题在哪里

`DressageEnvironment._build_harbor_mounts` 用 `_mounts` 建立实际的宿主路径映射。Harbor 的 `is_path_mounted` 查 `_host_mounts`。默认 `auto_mounting=False` 时，自动日志目录可能只出现在前者。Trial 因此继续调用后端 `download_dir`，非空目录触发 `shutil.Error`。 [实际宿主映射 · environment.py 第 537 行](../../../../dressage/integrations/harbor/environment.py#L537-L565) · [Dressage 的目录复制 · environment.py 第 467 行](../../../../dressage/integrations/harbor/environment.py#L467-L479) · [0.25 的两组挂载 · base.py 第 267 行](https://github.com/harbor-framework/harbor/blob/v0.25.0/src/harbor/environments/base.py#L267-L275) · [0.26 的两组挂载 · base.py 第 313 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/base.py#L313-L340) · [Trial 选择上传或下载的入口 · trial.py 第 815 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L815-L872)

```text
沙箱 /logs/agent → 宿主 trial/agent       实际映射到同一目录
is_path_mounted(/logs/agent, trial/agent) → False
在 trial/agent 放入一个文件，再调用 download_dir → shutil.Error
```

## 打算怎么接入

在 Dressage 后端构造日志映射时对齐真实绑定和 Harbor 查询所用的映射。先用测试锁定既有的 bwrap 直挂行为，再决定是否显式启用 Harbor 自动挂载。显式挂载按目标路径覆盖自动挂载，只读限制仍须生效。Harbor 的 bind 还可能附带 SELinux `z` 选项。

## 怎么验收

在 `test_environment.py` 放入非空 Agent 日志，通过 Trial 的回收入口证明直挂目录跳过复制且内容保留。在不同宿主目录上应实际复制成功。独立 verifier、artifacts 和显式挂载同样按真实目录判断。Trial 会记录部分复制异常，断言文件内容及选中的分支比只等 Trial 返回更可靠。 [已有文件和挂载用例 · test_environment.py 第 115 行](../../../../tests/integrations/harbor/test_environment.py#L115) · [独立 verifier 夹具](../03-verifier-fixture/README.md)

**本地复查**　运行本目录的 `python probe.py logs`。在两个候选版本中，实际宿主路径相同、挂载查询为 False、非空复制抛出 `shutil.Error`。脚本按 Trial 的挂载判断选分支，并调用真实后端方法。由此确定要修映射，修后还须从真实 Trial 回收入口验收。[探测脚本](probe.py) · [两版实测输出](log-recovery-output.txt) · [运行准备](../../reproduce.md#setup)

## 判断记录

- 2026-11-11　在 0.25 的静态对照中发现 `_mounts` 与 `_host_mounts` 分工改变。
- 2026-11-18　临时对齐 verifier 夹具后，四项环境测试通过。随后以非空日志单独调用真实 `download_dir`，在 0.26 复现目录复制错误，确认需要修改生产后端。
- 2026-11-18　用相同 Dressage 基线和临时日志复核 0.25、0.26。两版都观测到同一宿主目录、挂载查询为 False、非空复制抛出 `shutil.Error`。二进制定位在探测中替代，文件映射与复制使用真实方法。

[返回问题索引](../../README.md#issues)
