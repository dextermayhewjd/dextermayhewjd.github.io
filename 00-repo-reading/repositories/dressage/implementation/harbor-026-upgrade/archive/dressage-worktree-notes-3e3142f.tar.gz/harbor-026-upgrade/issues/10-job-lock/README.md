# 10 · Dressage 重建临时 Job 后，Harbor 还能生成 lock.json 吗？

**当前判断**　本地单题已验证，保留临时配置构造。

## 问题在哪里

`rollout._temporary_job_config` 按分区构造显式 tasks 并清空 datasets。Harbor `Job._init_job_lock` 根据已解析的任务查找下载记录并生成 lock，找不到对应任务时可能抛 `ValueError`。 [构造临时配置 · rollout.py 第 505 行](../../../../dressage/integrations/harbor/rollout.py#L505-L579) · [初始化 Job lock · job.py 第 961 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/job.py#L961) · [用解析结果构造 lock · lock.py 第 356 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/models/job/lock.py#L356)

## 打算怎么接入

继续让 Harbor 生成 lock。把 Dressage 临时 Job 配置交给真实 `Job.create`，保留本地题目的身份和来源。如果远程 dataset 路径验证失败，再检查来源被清理的位置。

## 怎么验收

用本地单题、两次尝试，调用 `_init_job_lock` 并核对任务和 schema。若 PR 声明远程 dataset 路径兼容，再从该输入经 `Job.run` 验证下载记录与 lock 能够配对。 [已有临时 Job 合同 · test_execution.py 第 456 行](../../../../tests/integrations/harbor/test_execution.py#L456)

**本地复查**　运行本目录的 `python probe.py`。程序从随仓最小本地题构造真实 Job，再调用 `_init_job_lock`。0.18 输出 schema 2，0.25 与 0.26 都输出 3，当前保留临时任务的构造方式。远程 dataset 的下载记录仍是另一项验收条件。[探测脚本](probe.py) · [三版实测输出](job-lock-output.txt)

## 判断记录

- 2026-11-18　在同一种本地输入上，0.18 生成 v2 lock，0.25 与 0.26 均生成 v3。直接探测停在 lock 构造，后续完整 Job、远程任务和重试需各自验收。

[返回问题索引](../../README.md#issues)
