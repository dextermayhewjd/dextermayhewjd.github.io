Identify the word "first".
