# 历史判断入口

每次核查的证据与修正已归入对应问题的 README。当前入口见[问题索引](README.md#issues)。

<a id="fixture-check"></a>

## 第一轮 bwrap 测试

[两项 verifier 测试为何失败](issues/03-verifier-fixture/README.md) · [另一项安装版本断言为何失败](issues/04-version-checks/README.md) · [非空日志回收如何改变后续修复范围](issues/02-output-mounts/README.md)

<a id="gemini-review"></a>

## 从原七项核查定位独立问题

| 原核查项 | 对应问题目录 |
| --- | --- |
| 1 · 环境契约 | [01 工厂预检的签名](issues/01-environment-preflight/README.md) · [02 非空日志目录被复制回自身](issues/02-output-mounts/README.md) · [03 独立 verifier 的测试夹具](issues/03-verifier-fixture/README.md) · [05 技能目录上传](issues/05-skills-upload/README.md) |
| 2 · Job 创建前的鉴权 | [06 Job 创建时的凭证检查](issues/06-agent-credential-preflight/README.md) |
| 3 · Agent 模型路由与输出脱敏 | [07 实际请求到达的 Gateway](issues/07-agent-routing/README.md) · [08 Trial 目录脱敏与 bundle 位置](issues/08-trial-output-redaction/README.md) |
| 4 · JobPlan 与 JobLock | [09 Trial 排列与原模板配对](issues/09-trial-plan/README.md) · [10 临时 Job 生成 lock](issues/10-job-lock/README.md) |
| 5 · 结果与失败处理 | [11 CANCEL 与 END 事件时序](issues/11-trial-events/README.md) · [12 评测有效分数与训练采纳](issues/12-reward-validity/README.md) · [13 重试后最终进入训练的尝试](issues/13-final-attempt/README.md) |
| 6 · 网络与 E2B | [14 bwrap 的阶段网络策略](issues/14-phase-network-policy/README.md) · [15 Agent 的 Web 工具开关](issues/15-web-tools/README.md) · [16 E2B 模板启动](issues/16-e2b-template/README.md) · [17 E2B 长任务续租](issues/17-e2b-renewal/README.md) |
| 7 · 配置与 checkpoint | [04 安装依赖与版本检查](issues/04-version-checks/README.md) · [18 随仓 Job YAML 的含义](issues/18-example-configs/README.md) · [19 旧数据源 checkpoint 的识别](issues/19-checkpoint-digests/README.md) |

工作树归属、Dressage 基线与目标版本的选择见[00 版本选择](issues/00-version-target/README.md)。
