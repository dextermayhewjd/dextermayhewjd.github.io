# 17 · 运行时间超过一个续租周期时，E2B 环境如何维持和回收？

**当前判断**　云端续租待验证。

## 问题在哪里

Harbor `E2BOptions` 的默认沙箱有效期为 3600 秒，默认续租间隔为 600 秒。`E2BEnvironment._renew_loop` 会对正在运行的沙箱设置新超时，`stop` 结束资源生命周期。 [有效期和续租间隔 · e2b.py 第 672 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/e2b.py#L672-L687) · [续租和停止 · e2b.py 第 1603 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/e2b.py#L1603-L1637) · [Dressage 选择 native 运行的配置 · rollout-native-remote.yaml](../../../../examples/harbor/dressage_profiles/rollout-native-remote.yaml)

## 打算怎么接入

在 native E2B 路径复用 Harbor 的续租和停止。先用可控的 SDK 替身观察超时更新与停止行为。如果 PR 承诺长任务成功运行，再记录一次经过续租周期的云端任务。

## 怎么验收

断言续租调用使用配置的有效期，停止后不会继续续租。云端验收另确认任务结束后的回收状态，并明确实测时间和条件。

**PR 判断依据**　现有参数和 `_renew_loop` 源码能够说明何时请求续租。当前没有云端长任务或 SDK 续租调用的运行记录，先保留 Harbor 的生命周期实现。[Harbor 的续租入口](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/e2b.py#L1603-L1613)

## 判断记录

- 2026-11-18　已有证据是 Harbor 0.26 的选项与实现。默认有效期为一小时，每次续租的默认间隔为十分钟，本轮没有运行云端长任务。

[返回问题索引](../../README.md#issues)
