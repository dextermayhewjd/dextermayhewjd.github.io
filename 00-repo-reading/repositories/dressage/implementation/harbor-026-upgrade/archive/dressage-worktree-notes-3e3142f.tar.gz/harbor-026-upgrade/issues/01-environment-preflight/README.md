# 01 · 为什么 0.26 的环境工厂调不进 Dressage 的 bwrap 预检？

**当前判断**　已在 0.26.0 复现，确定修复。

## 问题在哪里

Harbor 的 `EnvironmentFactory.run_preflight` 通过配置中的 import path 找到 `DressageEnvironment`。Dressage 定义的是 `preflight(cls)`。0.26 在进入函数体前就报 `TypeError`，提示不接受 `kwargs`。 [Dressage 的 preflight · environment.py 第 302 行](../../../../dressage/integrations/harbor/environment.py#L302) · [0.25 的调用方 · factory.py 第 265 行](https://github.com/harbor-framework/harbor/blob/v0.25.0/src/harbor/environments/factory.py#L265-L280) · [0.26 的调用方 · factory.py 第 314 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/factory.py#L314-L330)

```python
env_class.preflight()               # Harbor 0.25.0
env_class.preflight(kwargs=kwargs)  # Harbor 0.26.0
```

## 打算怎么接入

让 Dressage 的覆盖方法接受可选 `kwargs`，在 0.26 调用 `super().preflight(kwargs)`，随后继续原有的 Linux、可执行文件和 bwrap 检查。基类负责分派选项校验。当前后端没有声明选项模型，保持其现有配置来源。 [基类预检约定 · base.py 第 1144 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/base.py#L1144-L1159) · [未声明选项模型时的行为 · base.py 第 152 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/base.py#L152-L161)

## 怎么验收

把回归用例放在 `test_environment.py`。从真实 `EnvironmentFactory.run_preflight` 传入 Dressage 类路径，分别给 `None` 和空字典，断言基类收到原值、后端检查被调用。另保留现有对 bwrap 命令的断言。 [已有的 bwrap 直接调用测试 · test_environment.py 第 158 行](../../../../tests/integrations/harbor/test_environment.py#L158)

**本地复查**　运行本目录的 `python probe.py`。测试标记位于 bwrap 配置检查入口。0.18 和 0.25 能进入该位置，0.26 在传参处就失败，这是修改覆盖方法签名的直接依据。[探测脚本](probe.py) · [实测输出](preflight-output.txt) · [运行准备](../../reproduce.md#setup)

## 判断记录

- 2026-11-18　用两个版本的真实工厂将同一 import path 解析为独立 Dressage 工作树中的类。在 bwrap 配置检查处放入测试标记，0.25 到达标记，0.26 在参数绑定处报错。这个实验验证调用签名，完整的 bwrap 启动另行验收。

[返回问题索引](../../README.md#issues)
