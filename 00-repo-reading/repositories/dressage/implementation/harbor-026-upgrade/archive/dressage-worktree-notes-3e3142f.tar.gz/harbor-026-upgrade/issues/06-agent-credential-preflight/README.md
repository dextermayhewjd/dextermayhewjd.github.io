# 06 · 插件写入路由凭证之前，Harbor 会不会拒绝创建 Job？

**当前判断**　本地三个配置已通过 Job 创建，保留预检。

## 问题在哪里

普通 `Job.create` 会先检查 Agent 的模型配置，CLI 还有自己的 preflight。Dressage 使用已经创建的 Job 执行 `on_job_start`，这时才向待运行 Trial 的 Agent 写路由配置。 [CLI 检查入口 · jobs.py 第 113 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/cli/jobs.py#L113) · [Job 的 Agent 预检 · job.py 第 148 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/job.py#L148-L185) · [Dressage 接到 Job 的位置 · plugin.py 第 261 行](../../../../dressage/integrations/harbor/plugin.py#L261)

## 打算怎么接入

保留 Harbor 的凭证检查。对 PR 声明支持的 Agent、模型名以及显式 endpoint 各走一次创建流程。如果某个配置必须在插件运行之前提供连接信息，就在该配置的 Job 构造入口处理。

## 怎么验收

用本地题目、隔离的环境和测试配置创建真实 Job，断言能到达 `on_job_start`。在声明需要凭证的配置上单独验证缺失凭证时的行为。实际模型请求的去向由问题 07 验收。 [训练路径的临时 Job 配置 · rollout.py 第 505 行](../../../../dressage/integrations/harbor/rollout.py#L505-L579) · [Agent 最终连接 Gateway](../07-agent-routing/README.md)

**本地复查**　三个配置在未传入模型厂商凭证变量的子进程里均到达 `Job.create` 返回。保留 Job 预检，实际 harness 发请求留给问题 07。历史 CLI 帮助摘录中的 `--credential-mode` 属于 Hub `--launch` 路径。[Job 探测](../10-job-lock/probe.py) · [三版输出](../10-job-lock/job-lock-output.txt) · [CLI 帮助摘录](cli-help-excerpts.txt)

## 判断记录

- 2026-11-18　在清空宿主凭证的临时环境中，Claude Code + MiniMax-M3、Claude Code + Qwen/Qwen3.5-4B、Codex + openai/gpt-4o 均能在 0.25 和 0.26 创建本地 Job。Qwen 组合有模型识别警告。模型名只是该轮验证的输入，结论止于 Job 创建。

[返回问题索引](../../README.md#issues)
