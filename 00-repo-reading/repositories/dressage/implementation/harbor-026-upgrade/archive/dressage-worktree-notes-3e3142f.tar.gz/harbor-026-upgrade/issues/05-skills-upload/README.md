# 05 · 新路径 `/runtime/skills` 需要改 bwrap 目录常量吗？

**当前判断**　文件上传已实测可用，保留现有实现。

## 问题在哪里

Harbor 的默认技能路径由 `/harbor/skills` 变为 `/runtime/skills`。实际交接点是 Trial 上传技能目录时调用 `DressageEnvironment.upload_dir`，该方法先创建目标父目录。 [新版默认技能目录 · paths.py 第 46 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/models/trial/paths.py#L46) · [Trial 上传技能 · trial.py 第 1844 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L1844) · [bwrap 创建目录并上传 · environment.py 第 445 行](../../../../dressage/integrations/harbor/environment.py#L445-L457)

## 打算怎么接入

沿用 Harbor 选择的技能路径和现有上传实现。若接下来在真实 Agent 下观察到权限或可见性差异，在上传或执行入口定位。

## 怎么验收

用包含 `SKILL.md` 的目录上传到 `/runtime/skills/demo` 并读回文件。若 PR 承诺实际技能注入，再运行带技能的 Trial，检查 Agent 的运行用户能在 Harbor 选定的路径读取内容。

**本地复查**　从本目录运行 `python ../02-output-mounts/probe.py skills`。同一个最小输入在两个候选版本都上传成功，并读回 `SKILL.md`。依据这个结果保留现有父目录创建逻辑。真实 Agent 进程读取该文件是后续的验证边界。[文件探测](../02-output-mounts/probe.py) · [skills 实测输出](skills-upload-output.txt)

## 判断记录

- 2026-11-18　在临时 bwrap 根目录调用真实文件上传方法，0.25 和 0.26 均能从指定新路径读回同一份 `SKILL.md`。当前证据覆盖后端传输。

[返回问题索引](../../README.md#issues)
