# 15 · Harbor 切换 Web 工具状态会怎样影响 Agent 启动？

**当前判断**　保留 Harbor 的工具开关，目标 harness 待验证。

## 问题在哪里

在 0.25 与 0.26，`Trial._configure_web_tools` 根据当前网络策略调用 `agent.set_web_tools_disabled`。这个调用控制 Agent 的工具状态，发生在 Harbor 的 Trial 层。 [0.25 的工具配置 · trial.py 第 692 行](https://github.com/harbor-framework/harbor/blob/v0.25.0/src/harbor/trial/trial.py#L692-L699) · [0.26 的工具配置 · trial.py 第 700 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L700-L709) · [Agent 接收禁用标志 · base.py 第 197 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/agents/base.py#L197) · [Dressage 交给 Harbor 的 Agent 配置 · plugin.py 第 261 行](../../../../dressage/integrations/harbor/plugin.py#L261)

## 打算怎么接入

让 Harbor 继续配置 harness 的 Web 工具，Dressage 负责提供相符的 Gateway 和 bwrap 环境。对实际选用的 Agent 核对开关是否受支持，以及它的启动命令是否能正常执行。

## 怎么验收

在受限网络任务中捕获传入 Agent 的禁用标志，再运行一次目标 harness 的本地启动检查。以当前 harness 支持的工具开关为准，单独核对普通模型请求是否仍可走 Gateway。 [现有插件执行用例 · test_execution.py 第 64 行](../../../../tests/integrations/harbor/test_execution.py#L64) · [网络策略从哪里来](../14-phase-network-policy/README.md)

**PR 判断依据**　目前依据是两个发布标签中可定位的 `Trial._configure_web_tools`。前述 Job 探测停在创建或注册阶段，工具开关的实参和 Agent 启动效果仍待观察。[0.26 的工具开关调用](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/trial/trial.py#L703-L709)

## 判断记录

- 2026-11-18　源码确认两版都有这个调用。目前没有观察到独立的 Dressage 工具开关故障。

[返回问题索引](../../README.md#issues)
