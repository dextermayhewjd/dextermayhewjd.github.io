# 16 · native E2B 路径能否用目标版本的 SDK 和模板启动任务？

**当前判断**　云端运行待验证。

## 问题在哪里

Dressage 随仓的两个 Harbor Job 选择 E2B。Harbor 0.25 的 E2B extra 要求 `e2b>=2.25.0`，0.26 要求 `e2b>=2.52.0`。0.26 生成模板 tag 时包含资源规格和 recipe 版本 `r5`。 [Terminal-Bench 配置 · terminal-bench-2-e2b.yaml](../../../../examples/harbor/harbor_job_configs/terminal-bench-2-e2b.yaml) · [0.25 E2B 依赖 · pyproject.toml 第 68 行](https://github.com/harbor-framework/harbor/blob/v0.25.0/pyproject.toml#L68) · [0.26 E2B 依赖 · pyproject.toml 第 73 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/pyproject.toml#L73) · [模板名与资源 tag · e2b.py 第 528 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/e2b.py#L528-L568)

## 打算怎么接入

让 Harbor 的 native E2B 后端负责创建或选择模板。按目标版安装 E2B extra，传入现有 Job 的资源配置，并按随仓 native-remote profile 配置 Gateway。模板名应从实际资源和 Harbor 生成规则得出。

## 怎么验收

在具备 E2B 账户与可达 Gateway 的环境，从随仓 Job 启动一份任务，记录实际选用的模板及能否执行和回传结果。仅完成 YAML 解析时，记录为配置验证。 [Harbor 确保模板可用 · e2b.py 第 1365 行](https://github.com/harbor-framework/harbor/blob/v0.26.0/src/harbor/environments/e2b.py#L1365) · [云端 rollout 测试 · test_gated_e2e.py 第 93 行](../../../../tests/integrations/harbor/test_gated_e2e.py#L93) · [远端 Gateway 连接条件 · harbor.md 第 104 行](../../../../docs/harbor.md#L104)

**PR 判断依据**　配置探测确实解析出 `e2b`，默认套件排除了云端用例。当前证据支持保留 Job 配置，E2B 模板构建和真实任务启动仍待有条件的环境验证。[配置实测结果](../18-example-configs/job-config-output.txt) · [默认套件排除项](../00-version-target/pytest-replay.txt)

## 判断记录

- 2026-11-18　已核对两个发布版的 E2B 依赖和 0.26 的模板生成逻辑。此前举出的 CPU 和内存只是一个资源配置实例。云端构建、启动均待执行。

[返回问题索引](../../README.md#issues)
