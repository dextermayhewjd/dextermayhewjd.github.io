# Dressage 适配 Harbor 0.26.0

**建议直接以 Harbor 0.26.0 为本次 PR 的目标。** 升级在独立 Dressage 仓库的 `compat/harbor-0.26` 工作树进行，Dressage 基线为 `3e3142f`。`0.18.0` 用于回归对照，`0.25.0` 用于定位行为从哪一版开始改变。[两个目标版本的取舍](issues/00-version-target/README.md)

**先看 [01 环境工厂预检](issues/01-environment-preflight/README.md)，再看 [02 日志回收](issues/02-output-mounts/README.md)。** 这两处都在生产代码中复现了问题。[03 verifier 夹具](issues/03-verifier-fixture/README.md)解释现有测试为何失败。[04 版本检查](issues/04-version-checks/README.md)列出适配通过后需要同步更新的安装和运行入口。

**复查证据**　各问题的「怎么验收」下有探测脚本、实测输出或该问题尚缺的证据。要复现某个现象，从对应问题打开材料。共用的安装步骤和临时实验的去向见[复现说明](reproduce.md)。

<a id="issues"></a>

## 问题索引

每个目录维护一个问题。在它的 README 中可以直接找到调用方与源码行、拟采用的接法、验收用例和历次判断。新证据追加到对应问题的「判断记录」。

| 编号 | 打开一个问题 | 目前有何依据 |
| --- | --- | --- |
| 00 | [版本建议](issues/00-version-target/README.md) | 建议 0.26.0 |
| 01 | [工厂预检的签名](issues/01-environment-preflight/README.md) | 已复现，修后端 |
| 02 | [非空日志目录被复制回自身](issues/02-output-mounts/README.md) | 两版均复现，修后端 |
| 03 | [独立 verifier 的测试夹具](issues/03-verifier-fixture/README.md) | 已定位，对齐测试入参 |
| 04 | [安装依赖与版本检查](issues/04-version-checks/README.md) | 适配验收后更新版本声明 |
| 05 | [技能目录上传](issues/05-skills-upload/README.md) | 文件读写已过，暂保留 |
| 06 | [Job 创建时的凭证检查](issues/06-agent-credential-preflight/README.md) | 三个配置已通过 Job 创建 |
| 07 | [实际请求到达的 Gateway](issues/07-agent-routing/README.md) | 0.26 的实际请求待验 |
| 08 | [Trial 目录脱敏与 bundle 位置](issues/08-trial-output-redaction/README.md) | 路径约束已确认，文件验收待补 |
| 09 | [Trial 排列与原模板配对](issues/09-trial-plan/README.md) | 已有真实 Job 探测 |
| 10 | [临时 Job 生成 lock](issues/10-job-lock/README.md) | 本地 lock 已验证 |
| 11 | [CANCEL 与 END 事件时序](issues/11-trial-events/README.md) | 已验证注册，事件执行待验 |
| 12 | [评测有效分数与训练采纳](issues/12-reward-validity/README.md) | 保留现有规则，补对照 |
| 13 | [重试后最终进入训练的尝试](issues/13-final-attempt/README.md) | 保留最终选择，补真实交接 |
| 14 | [bwrap 的阶段网络策略](issues/14-phase-network-policy/README.md) | 多步任务待验 |
| 15 | [Agent 的 Web 工具开关](issues/15-web-tools/README.md) | 目标 harness 待验 |
| 16 | [E2B 模板启动](issues/16-e2b-template/README.md) | 云端启动待验 |
| 17 | [E2B 长任务续租](issues/17-e2b-renewal/README.md) | 云端续租待验 |
| 18 | [随仓 Job YAML 的含义](issues/18-example-configs/README.md) | 两份 YAML 在三个版本均可解析 |
| 19 | [旧数据源 checkpoint 的识别](issues/19-checkpoint-digests/README.md) | 已观测摘要变化，跨版恢复待验 |

## PR 验收

1. 在目标版补齐真实环境工厂和非空日志的回归测试，再运行 `python -m pytest -q tests/integrations/harbor`。此次重跑同一份未修改的 Dressage 基线，0.18.0 通过 66 项，0.25.0 和 0.26.0 均通过 63 项、失败 3 项。三个版本各排除 8 项 `harbor_e2e`。[实际失败项](issues/00-version-target/pytest-replay.txt)
2. 验收 Dressage 自带的两条入口。对 CLI rollout 核对正常与取消的 Trial 及路由收尾。对训练接入核对重试后返回的 Sample、组内归属和最终 manifest。报告实际执行的入口及尚待运行的云端或训练用例。
3. 在 PR 中列出支持的精确版本、变更的行为、回归结果及旧 checkpoint 的处理。若上游要求增加一个支持版本，加入同一套安装与运行验收。[GitHub 的可评审变更指南](https://docs.github.com/en/pull-requests/concepts/helping-others-review-your-changes)

更多源码入口见 [Dressage 的 Harbor 集成说明](../harbor.md) · [接入实现](../../dressage/integrations/harbor/) · [测试套件](../../tests/integrations/harbor/)。
