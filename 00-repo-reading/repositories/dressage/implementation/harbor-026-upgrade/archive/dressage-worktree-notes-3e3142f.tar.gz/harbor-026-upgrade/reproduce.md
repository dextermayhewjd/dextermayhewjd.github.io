# 在独立 Dressage 工作树复查升级依据

本次对照统一使用 Dressage `3e3142f`、Python 3.12 和 Harbor `0.18.0`、`0.25.0`、`0.26.0`。每个问题的 README 记录修改理由及验收边界。实验脚本和输出随对应问题保存，共用一次实验的条目链接到同一份输出。[问题索引](README.md#issues)

<a id="setup"></a>
## 准备单个版本的复查环境

在独立 Dressage 工作树根目录执行。每个版本使用一个 Python 环境。基线的 `.[harbor]` 固定 0.18.0，因此用于调查候选版本时，单独选择 Harbor 包，并从当前 Dressage checkout 安装自带的 blackbox server。

```bash
harbor_version=0.26.0
env_dir="../.venvs/dressage-harbor-$harbor_version"
python3.12 -m venv "$env_dir"
. "$env_dir/bin/activate"
python -m pip install -e '.[test]' ./blackbox_server "harbor==$harbor_version"
export PYTHONPATH="$PWD"
export LITELLM_LOCAL_MODEL_COST_MAP=True
export HF_HUB_OFFLINE=1
python -c 'import dressage; from pathlib import Path; from importlib.metadata import version; print(version("harbor"), dressage.__file__); assert Path(dressage.__file__).resolve().parent == Path.cwd().resolve() / "dressage"'
```

这些命令描述独立安装方式。本次本地复跑复用了已装的 Python 依赖和用发布标签构建的 Harbor 包，导入的是独立 Dressage 基线导出的源码。测试进程没有传入模型厂商凭证。LiteLLM 对 Qwen 的模型名给过识别警告，Job 仍创建成功。干净环境的安装验收属于[问题 04](issues/04-version-checks/README.md)。

<a id="run-probes"></a>
## 重跑一次观察

下面的命令从 Dressage 根目录执行。输出文件保存的是迁入后的实际 stdout。探测脚本会报告基线的已知错误，因此应对照输出中的调用、状态或异常判断行为。

| 要查的证据 | 在仓库根目录执行 | 可对照的输出 |
| --- | --- | --- |
| 01 工厂是否进入 bwrap 预检 | `python docs/harbor-026-upgrade/issues/01-environment-preflight/probe.py` | [三个版本](issues/01-environment-preflight/preflight-output.txt) |
| 02 非空目录是否触发重复复制 | `python docs/harbor-026-upgrade/issues/02-output-mounts/probe.py logs` | [0.25 和 0.26](issues/02-output-mounts/log-recovery-output.txt) |
| 05 技能文件能否读回 | `python docs/harbor-026-upgrade/issues/02-output-mounts/probe.py skills` | [0.25 和 0.26](issues/05-skills-upload/skills-upload-output.txt) |
| 04、09、11 版本检查、Trial 排列和钩子注册 | `python docs/harbor-026-upgrade/issues/09-trial-plan/probe.py` | [三个版本](issues/09-trial-plan/trial-plan-output.txt) |
| 06、10 本地 Job 创建与 lock schema | `python docs/harbor-026-upgrade/issues/10-job-lock/probe.py` | [三个版本和三个 Agent 配置](issues/10-job-lock/job-lock-output.txt) |
| 18、19 两份 YAML 解析出的字段和 source 摘要 | `python docs/harbor-026-upgrade/issues/18-example-configs/probe.py` | [三个版本](issues/18-example-configs/job-config-output.txt) |

Job 探测默认读取随仓两道最小本地题，只执行配置、计划、注册和 lock 操作。历史探测使用 Harbor 的 `hello-world` 和 `hello-alpine`。如要对照同一输入，计划探测接受 `--tasks <hello-world 目录> <hello-alpine 目录>`，lock 探测接受 `--task <hello-world 目录>`。模型名只作为构造 Job 的输入。[第一道输入](issues/09-trial-plan/tasks/first/task.toml) · [第二道输入](issues/09-trial-plan/tasks/second/task.toml)

<a id="suite"></a>
## 重跑默认套件与一行夹具对照

先在未修改的 `3e3142f` 运行默认 Harbor 套件。Linux 环境中 `bwrap`、`claude`、`curl` 和 `python3` 可用时，仓库的真实 bwrap 用例才会执行。pytest 会说明跳过和排除的用例。[原始 0.18 日志](issues/00-version-target/pytest-0.18.0.txt) · [原始 0.26 日志](issues/00-version-target/pytest-0.26.0.txt) · [本次三版复跑的失败项与计数](issues/00-version-target/pytest-replay.txt)

```bash
python -m pytest -p no:cacheprovider -m "not harbor_e2e" --tb=line -q -r f tests/integrations/harbor
```

保持当前工作树的测试和后端原样，在单独导出的基线上应用问题 03 的夹具差异。运行此对照时选择 Harbor 0.26.0。补丁只将传给 verifier 的 `mounts` 换为 `auto_mounts`。[实际补丁](issues/03-verifier-fixture/auto-mounts.patch) · [应用补丁后的输出](issues/03-verifier-fixture/fixture-pytest.txt)

```bash
upgrade_dir="$PWD/docs/harbor-026-upgrade"
python_bin="$(python -c 'import sys; print(sys.executable)')"
fixture_dir="$(mktemp -d)"
git archive 3e3142f | tar -x -C "$fixture_dir"
(
    cd "$fixture_dir" || exit 1
    git apply --check "$upgrade_dir/issues/03-verifier-fixture/auto-mounts.patch" &&
    git apply "$upgrade_dir/issues/03-verifier-fixture/auto-mounts.patch" &&
    PYTHONPATH="$PWD" "$python_bin" -m pytest -p no:cacheprovider -q tests/integrations/harbor/test_environment.py
)
```

<a id="provenance"></a>
## 原临时材料现在在哪里

| 原材料 | 工作树内的归属 |
| --- | --- |
| `compare_versions.py` 与 `mounts.py` | 工厂调用在 [01](issues/01-environment-preflight/probe.py)。后端文件操作在 [02](issues/02-output-mounts/probe.py)，分为 `logs` 和 `skills` 两个独立观察。 |
| 两个版本的 `probe.py` | [09 的计划与钩子探测](issues/09-trial-plan/probe.py)保留原始版本检查、进程内临时放行和内存 Gateway。可直接从本仓库输入构造真实 Job。 |
| `audit.py` | [10 的 Job/lock 探测](issues/10-job-lock/probe.py)与 [18 的 YAML/摘要探测](issues/18-example-configs/probe.py)。工厂检查收在 01。 |
| `suite.log`、修改过的 verifier 夹具、`help018` 和 `help025` | 00 保存原始测试输出，去掉个人路径前缀及行尾空格。03 保存真正的一行差异和复跑结果。06 留存与插件加载、凭证模式有关的 [CLI 帮助摘录](issues/06-agent-credential-preflight/cli-help-excerpts.txt)。 |
| `new/` 的 20 个问题目录与 `check_docs.py` | 问题正文已迁入 [issues](README.md#issues)。[文档校验工具](check_docs.py)从自己的位置解析相对路径。 |

可用 `python docs/harbor-026-upgrade/check_docs.py` 检查索引和本地链接。如果另有包含发布标签的 Harbor checkout，加 `--harbor-repo <checkout>` 可核对上游源码行号。[回到问题索引](README.md#issues)
